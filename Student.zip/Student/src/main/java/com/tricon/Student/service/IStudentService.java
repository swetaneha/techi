package com.tricon.Student.service;

import java.util.List;

import com.tricon.Student.model.Student;

public interface IStudentService {
	public List<Student>  getName();
}
